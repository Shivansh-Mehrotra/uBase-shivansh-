from django.apps import AppConfig


class RoleConfig(AppConfig):
    name = 'core.apps.role'
    verbose_name = "Role and App Source"

